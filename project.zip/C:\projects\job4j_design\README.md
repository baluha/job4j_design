# job4j_design
[![Build Status](https://app.travis-ci.com/baluha/job4j_design.svg?branch=master)](https://app.travis-ci.com/baluha/job4j_design)
[![codecov](https://codecov.io/gh/baluha/job4j_design/branch/main/graph/badge.svg?token=UOCiSTHBhg)](https://codecov.io/gh/baluha/job4j_design)