package ru.job4j.io;

import org.junit.Test;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ConfigTest {

    @Test
    public void whenPairWithoutComment() {
        String path = "./data/with_comments.properties";
        Config config = new Config(path);
        config.load();
        assertThat(config.value("name"), is("Roman"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void whenPairWithEmpty() {
        String path = "./data/empty_lines.properties";
        Config config = new Config(path);
        config.load();
    }

}